ETHOS INTERNATIONAL SCHOOL - STUDENT COUNCIL VOTE
=================================================
1) Upload the whole folder "ethos-vote" to your web hosting (PHP 7.4+ with SQLite, which almost every host has).
   Example: https://yoursite.com/vote/
2) Make sure the folder is writable (the "data" folder and votes.sqlite are created automatically).
3) Open https://yoursite.com/vote/  ->  the QR code on the "Scan a QR Code" screen is now the real link.
4) Teacher results: "Teacher results" button on a PC, password  Eis@Ethos@123
   (change it at the top of api.php).
5) Before the REAL election: open Results -> "Reset all votes" once to clear any test votes.

Use HTTPS so phones keep the "already voted" cookie safely.
