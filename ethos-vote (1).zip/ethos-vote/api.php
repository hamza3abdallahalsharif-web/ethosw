<?php
/* ==========================================================================
   Ethos International School – Student Council Vote – BACKEND
   Collects every vote from every phone and PC in ONE place (SQLite file).
   No database setup needed: the file  data/votes.sqlite  is created automatically.
   ========================================================================== */

const TEACHER_PASSWORD = 'Eis@Ethos@123';   // <-- change the results password here

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');

function out(array $d, int $code = 200): void {
    http_response_code($code);
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------- storage folder (protected from the web) ---------- */
$dir = __DIR__ . '/data';
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
if (!is_file($dir . '/.htaccess')) {
    @file_put_contents($dir . '/.htaccess',
        "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
}
if (!is_file($dir . '/index.html')) { @file_put_contents($dir . '/index.html', ''); }

try {
    $db = new PDO('sqlite:' . $dir . '/votes.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec('PRAGMA busy_timeout = 8000');
    $db->exec('CREATE TABLE IF NOT EXISTS devices (token TEXT PRIMARY KEY, year INTEGER, ts INTEGER)');
    $db->exec('CREATE TABLE IF NOT EXISTS votes (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, mode TEXT, year INTEGER, cand1 TEXT, cand2 TEXT)');
} catch (Throwable $e) {
    out(['ok' => false, 'error' => 'database'], 500);
}

/* ---------- input ---------- */
$action = $_GET['action'] ?? '';
$raw = file_get_contents('php://input');
$in = json_decode($raw ?: '[]', true);
if (!is_array($in)) { $in = []; }

/* ---------- helpers ---------- */
function device_tokens(array $in): array {
    $t = [];
    if (isset($_COOKIE['ethos_dt'])) { $t[] = (string)$_COOKIE['ethos_dt']; }
    foreach ((array)($in['tokens'] ?? []) as $x) { $t[] = (string)$x; }
    $ok = [];
    foreach ($t as $x) { if (preg_match('/^[a-f0-9]{32}$/', $x) && !in_array($x, $ok, true)) { $ok[] = $x; } }
    return $ok;
}
function set_token_cookie(string $tok): void {
    setcookie('ethos_dt', $tok, [
        'expires'  => time() + 315360000,   // 10 years
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}
function locked_token(PDO $db, array $tokens): ?string {
    $s = $db->prepare('SELECT 1 FROM devices WHERE token = ?');
    foreach ($tokens as $t) {
        $s->execute([$t]);
        if ($s->fetchColumn()) { return $t; }
    }
    return null;
}
function need_password(array $in): void {
    $p = (string)($in['password'] ?? '');
    if (!hash_equals(TEACHER_PASSWORD, $p)) {
        usleep(500000);
        out(['ok' => false, 'error' => 'auth'], 403);
    }
}
function is_mobile_ua(): bool {
    return (bool)preg_match('/Android|iPhone|iPad|iPod|Mobile/i', $_SERVER['HTTP_USER_AGENT'] ?? '');
}

/* ---------- actions ---------- */
switch ($action) {

    case 'ping':
        out(['ok' => true, 'app' => 'ethos-vote']);

    /* Is this phone already blocked? Also hands out / re-syncs the device token. */
    case 'status': {
        $tokens = device_tokens($in);
        $lt = locked_token($db, $tokens);
        $tok = $lt ?? ($tokens[0] ?? bin2hex(random_bytes(16)));
        set_token_cookie($tok);
        out(['ok' => true, 'locked' => $lt !== null, 'token' => $tok]);
    }

    /* Save one ballot (exactly 2 candidates). */
    case 'vote': {
        $mode  = (string)($in['mode'] ?? '');
        $year  = (int)($in['year'] ?? 0);
        $picks = $in['picks'] ?? [];

        if (!in_array($mode, ['phone', 'pc'], true)) { out(['ok' => false, 'error' => 'mode'], 400); }
        if ($mode === 'phone' && ($year < 7 || $year > 10)) { out(['ok' => false, 'error' => 'year'], 400); }
        if ($mode === 'pc') {
            if ($year < 4 || $year > 6) { out(['ok' => false, 'error' => 'year'], 400); }
            if (is_mobile_ua()) { out(['ok' => false, 'error' => 'pc_only'], 400); }
        }
        if (!is_array($picks) || count($picks) !== 2) { out(['ok' => false, 'error' => 'picks'], 400); }
        $picks = array_values($picks);
        if ($picks[0] === $picks[1]) { out(['ok' => false, 'error' => 'duplicate'], 400); }
        foreach ($picks as $p) {
            if (!is_string($p) || !preg_match('/^(\d{1,2})[A-D]-[1-6]$/', $p, $m) || (int)$m[1] !== $year) {
                out(['ok' => false, 'error' => 'candidate'], 400);
            }
        }

        if ($mode === 'pc') {
            $db->prepare('INSERT INTO votes (ts, mode, year, cand1, cand2) VALUES (?,?,?,?,?)')
               ->execute([time(), 'pc', $year, $picks[0], $picks[1]]);
            out(['ok' => true]);
        }

        /* phone: one vote per device, checked + written in ONE locked transaction */
        $tokens = device_tokens($in);
        $tok = $tokens[0] ?? bin2hex(random_bytes(16));
        try {
            $db->exec('BEGIN IMMEDIATE');
            $lt = locked_token($db, $tokens);
            if ($lt !== null) {
                $db->exec('ROLLBACK');
                set_token_cookie($lt);
                out(['ok' => false, 'locked' => true, 'token' => $lt]);
            }
            $ins = $db->prepare('INSERT OR IGNORE INTO devices (token, year, ts) VALUES (?,?,?)');
            $all = $tokens; if (!in_array($tok, $all, true)) { $all[] = $tok; }
            foreach ($all as $t) { $ins->execute([$t, $year, time()]); }
            $db->prepare('INSERT INTO votes (ts, mode, year, cand1, cand2) VALUES (?,?,?,?,?)')
               ->execute([time(), 'phone', $year, $picks[0], $picks[1]]);
            $db->exec('COMMIT');
        } catch (Throwable $e) {
            try { $db->exec('ROLLBACK'); } catch (Throwable $e2) {}
            out(['ok' => false, 'error' => 'database'], 500);
        }
        set_token_cookie($tok);
        out(['ok' => true, 'token' => $tok]);
    }

    /* Teacher: totals for every candidate. */
    case 'results': {
        need_password($in);
        $counts = [];
        foreach ($db->query('SELECT cand1 AS c FROM votes UNION ALL SELECT cand2 AS c FROM votes') as $r) {
            $counts[$r['c']] = ($counts[$r['c']] ?? 0) + 1;
        }
        $b = ['total' => 0, 'phone' => 0, 'pc' => 0];
        $years = [];
        foreach ($db->query('SELECT mode, year, COUNT(*) AS n FROM votes GROUP BY mode, year') as $r) {
            $n = (int)$r['n'];
            $b['total'] += $n;
            $b[$r['mode']] += $n;
            $years[$r['year']] = ($years[$r['year']] ?? 0) + $n;
        }
        $b['years'] = (object)$years;
        out(['ok' => true, 'counts' => (object)$counts, 'ballots' => $b, 'ts' => time()]);
    }

    /* Teacher: wipe everything (use before the real election). */
    case 'reset': {
        need_password($in);
        $db->exec('DELETE FROM votes');
        $db->exec('DELETE FROM devices');
        out(['ok' => true]);
    }

    default:
        out(['ok' => false, 'error' => 'unknown_action'], 400);
}
